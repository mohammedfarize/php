<?php


$width = 815;
$height = 315;

$base_image = imagecreatefromjpeg("base1.jpg");
$top_image = imagecreatefromjpeg("base.jpg");
#$top_image = imagecreatefrompng("cover.png");
$merged_image = "merged1.jpg";

imagesavealpha($top_image, true);
imagealphablending($top_image, true);

imagecopy($base_image, $top_image, 500, 0, 0, 0, $width, $height);
imagepng($base_image, $merged_image);


 $base_image = imagecreatefrompng ("merged1.jpg");

$top_image = imagecreatefrompng("cover.png");
$merged_image = "merged.png";

imagesavealpha($top_image, true);
imagealphablending($top_image, true);

imagecopy($base_image, $top_image, 0, 0, 0, 0, $width, $height);
imagepng($base_image, $merged_image);

?>