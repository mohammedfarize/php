<?php 
/** 
* $image image cursor (from imagecreatetruecolor) 
* $backgound image curosr (from imagecolorallocate) 
* $paddng int 
*/ 
$image="merged1.png"
    imageCrop($image);
function imageCrop($image, $background = false, $padding = 0) { 
    if($background) 
      $background = imagecolorallocate($image, 255, 255, 255); 
    
    $top = imageSY($image); 
    $left = imageSX($image); 
    $bottom = 0; 
    $right = 0; 
    
    for ($x = 0 ; $x < imagesx($image) ; $x++) { 
        for ($y = 0 ; $y < imagesy($image) ; $y++) { 
          
          // if there match 
            if(imagecolorat($image, $x, $y) != $background) { 
              
              if($x < $left) 
                $left = $x; 
              if($x > $right) 
                $right = $x; 
              if($y > $bottom) 
                $bottom = $y; 
              if($y < $top) 
                $top = $y; 
        } 
        } 
    } 
    
    $right++; 
    $bottom++; 
    
    // create new image with padding 
    $img = imagecreatetruecolor($right-$left+$padding*2,$bottom-$top+$padding*2); 
    // fill the background 
    imagefill($img, 0, 0, $background); 
    // copy 
    imagecopy($img, $image, $padding, $padding, $left, $top, $right-$left, $bottom-$top); 
    
    // destroy old image cursor 
    imagedestroy($image); 
    return $img; 
} 
?>


<?php
function ImageFlip ( $imgsrc, $mode )
{

    $width                        =    imagesx ( $imgsrc );
    $height                       =    imagesy ( $imgsrc );

    $src_x                        =    0;
    $src_y                        =    0;
    $src_width                    =    $width;
    $src_height                   =    $height;

    switch ( $mode )
    {

        case '1': //vertical
            $src_y                =    $height -1;
            $src_height           =    -$height;
        break;

        case '2': //horizontal
            $src_x                =    $width -1;
            $src_width            =    -$width;
        break;

        case '3': //both
            $src_x                =    $width -1;
            $src_y                =    $height -1;
            $src_width            =    -$width;
            $src_height           =    -$height;
        break;

        default:
            return $imgsrc;

    }

    $imgdest                    =    imagecreatetruecolor ( $width, $height );

    if ( imagecopyresampled ( $imgdest, $imgsrc, 0, 0, $src_x, $src_y , $width, $height, $src_width, $src_height ) )
    {
        return $imgdest;
    }

    return $imgsrc;

}
?>